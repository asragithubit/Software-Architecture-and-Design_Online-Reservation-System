#include <iostream>
using namespace std;

class AuthenticationService
{
private:
    static AuthenticationService* instance;
    AuthenticationService() {}

public:
    static AuthenticationService* getInstance()
    {
        if (!instance)
        {
            instance = new AuthenticationService();
        }
        return instance;
    }

    bool verifyEmail(const std::string& email)
    {
        cout << "Verifying email: " << email << endl;
        return true;
    }

    bool login(const std::string& username, const std::string& password)
    {
        cout << "Logging in user: " << username << endl;
        return true;
    }

    bool resetPassword(const std::string& email)
    {
        cout << "Resetting password for email: " << email << endl;
        return true; 
    }
};

AuthenticationService* AuthenticationService::instance = nullptr;

int main()
{
    AuthenticationService* authService1 = AuthenticationService::getInstance();
    AuthenticationService* authService2 = AuthenticationService::getInstance();

    cout << "Is authService1 == authService2? " << (authService1 == authService2 ? "Yes" : "No") << endl;

    authService1->verifyEmail("example@example.com");
    authService1->login("username", "password");
    authService1->resetPassword("example@example.com");

    delete authService1; 
    return 0;
}
