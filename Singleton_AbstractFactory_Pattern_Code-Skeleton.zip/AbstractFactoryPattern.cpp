#include <iostream>
#include <string>
using namespace std;

class Reservation
{
public:
	virtual void book() = 0;
};


//Concrete Classes
class HotelRoomReservation : public Reservation
{
public:
	void book() override
	{
		cout << "Booking hotel room reservation..." << endl;
	}
};

class EventReservation : public Reservation
{
public:
	void book() override
	{
		cout << "Booking event reservation..." << endl;
	}
};

class ReservationFactory
{
public:
	virtual Reservation* createReservation() = 0;
};

class HotelRoomReservationFactory : public ReservationFactory
{
public:
	Reservation* createReservation() override
	{
		return new HotelRoomReservation();
	}
};

class EventReservationFactory : public ReservationFactory
{
public:
	Reservation* createReservation() override
	{
		return new EventReservation();
	}
};

int main()
{
	ReservationFactory* hotelRoomFactory = new HotelRoomReservationFactory();
	Reservation* hotelRoomReservation = hotelRoomFactory->createReservation();
	hotelRoomReservation->book();

	ReservationFactory* eventFactory = new EventReservationFactory();
	Reservation* eventReservation = eventFactory->createReservation();
	eventReservation->book();

	delete hotelRoomFactory;
	delete hotelRoomReservation;
	delete eventFactory;
	delete eventReservation;

	return 0;
}
